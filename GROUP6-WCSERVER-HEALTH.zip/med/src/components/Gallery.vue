<template>
    <div class="gallery">
      <h1>Welcome to my Gallery Page</h1>
      <img id = "Medic" src = "https://www.cbhs.com.au/images/librariesprovider2/default-album/does-hay-fever-have-anything-to-do-with-hay.tmb-articledet.png?Status=Master&sfvrsn=77693229_2">
      <h2> A woman is meditating in the grass with her yoga mat</h2>
      <img id = "Medic" src = "https://media.bizj.us/view/img/12198742/211independ*1200xx1193-670-0-0.jpg">
      <h2> A person is consulting a woman that has mental issues</h2>
      <img id = "Medic" src = "https://www.dlcv.org/wp-content/uploads/2022/03/AdobeStock_297322581-scaled.jpeg">
      <h2> A group of people helping a depressed woman</h2>
      <img id = "Medic" src = "https://bamboohealth.com/wp-content/uploads/2022/10/134421109_l-scaled-1-1024x683.jpg">
      <h2> A group of people helping a person with suicidal thoughts</h2>
      <img id = "Medic" src = "https://npr.brightspotcdn.com/dims4/default/dec7bb2/2147483647/strip/true/crop/720x443+0+48/resize/880x542!/quality/90/?url=http%3A%2F%2Fnpr-brightspot.s3.amazonaws.com%2F08%2Fa7%2Fd20b9c9b4bd4adb894eb5a3bc633%2F21640772-10159312460770048-8396612542568946324-o.jpg">
      <h2>A person showing her that is right to speak up and be brave for it</h2>
      <img id = "Medic" src = "https://www.pmhacci.com/wp-content/uploads/2022/06/Lubas.jpg">
      <h2>Seminar about self awareness</h2>
      <img id = "Medic" src = "https://shrm-res.cloudinary.com/image/upload/c_crop,h_408,w_724,x_0,y_9/w_auto:100,w_1200,q_35,f_auto/v1/Benefits/counseling-wellbeing_wgllv6.jpg">
      <h2>A therapist helping her patient </h2>
      <img id = "Medic" src = "https://sageclinic.org/wp-content/uploads/2022/03/march-banner.png">
      <h2>2 woman helping their friend that is going through a breakup with his boyfriend</h2>

      
    </div>
  </template>
  
  <script>
  export default {
    name: 'gallery',
    data () {
      return {
        title: 'Gallery'
      }
    }
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped>

  #Medic{
    text-align: center;
    width: 900px;
  }

  img{
    margin: 30px 0px 20px 0px;

  }
 
  
  </style>
  