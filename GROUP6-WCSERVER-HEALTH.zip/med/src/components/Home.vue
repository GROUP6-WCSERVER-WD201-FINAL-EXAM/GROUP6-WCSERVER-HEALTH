<template>
    <div>
       
        <!-- PRELOADER -->
        <div class="preloader">
           
            <div class="spinner"></div>
            
        </div>
        <!-- /PRELOADER -->
    
        
        <!-- IMAGE CONTAINER -->
        <div class="image-container">
           
            <div class="background-img"></div>

        </div>
        <!-- /IMAGE CONTAINER -->


        <!-- CONTENT AREA -->
        <div class="content-area">


            <!-- CONTENT AREA INNER --> 
            <div class="content-area-inner">


                <!-- INTRO -->
                <section id="intro">


                    <!-- CONTAINER MID -->
                    <div class="container-mid">

                       
                        <!-- ANIMATION CONTAINER -->
                        <div class="animation-container animation-fade-down" data-animation-delay="0">
                        
                            <h1>Rise with us</h1>
                            <h3 class="tagline">"Together we can make it."</h3>
                        
                        </div>
                        <!-- /ANIMATION CONTAINER -->
                        
                        
                        <!-- ANIMATION CONTAINER -->
                        <div class="animation-container animation-fade-left" data-animation-delay="300">
                           
                            <p class="subline">Rise with me is a Web Application Project designed to provide information, resources, and support for individuals seeking help and information related to mental health issues. This Web app also serves as an online-source that collects and recommends existing mental health-related advocacies, activities, webinars, selling/buying for a cause that promote welfare, wellness and awareness. Overall, the “Rise with me” project aims to help understand mental health issues, reduce stigma, and provide resources and support to those in need.</p>
                            
                        </div>
                        <!-- /ANIMATION CONTAINER -->
                        
                        
                        <!-- ANIMATION CONTAINER -->
                        <div class="animation-container animation-fade-up" data-animation-delay="600">
                           
                            <a href="#about" class="smooth-scroll">Learn More<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            
                        </div>
                        <!-- /ANIMATION CONTAINER -->


                    </div>
                    <!-- /CONTAINER MID -->


                </section>
                <!-- /INTRO -->


                <!-- ABOUT -->
                <section id="about">


                    <h3 class="headline scroll-animated-from-right">About us</h3>
                    
                    <p class="scroll-animated-from-right">The "Rise with us" project was begun last December 2022 by the following Holy Angel University students who had a new perspective on how they could help those who were experiencing mental health struggles. This project was made to be a web application to reach far more audiences across the internet. It is an easy-access and online source of various Information that would be of help to spread awareness, correct misinterpretations and break stigma.</p>

                   


                </section>
                <!-- /ABOUT -->
                
                
                <!-- SERVICE -->
                <section id="service">


                    <h3 class="headline scroll-animated-from-right">What we promote</h3>
                    
                    
                    <!-- SERVICE LIST -->
                    <ul class="services-list">
                       
                       
                        <li class="scroll-animated-from-right"><i class="fa fa-file-o" aria-hidden="true"></i>Advocacies</li>
                        <li class="scroll-animated-from-right"><i class="fa fa-file-video-o" aria-hidden="true"></i>Webinars</li>
                        <li class="scroll-animated-from-right"><i class="fa fa-shopping-bag" aria-hidden="true"></i>Sell for a cause</li>
                        <li class="scroll-animated-from-right"><i class="fa fa-users" aria-hidden="true"></i>Programs</li>
                        <li class="scroll-animated-from-right"><i class="fa fa-user-md" aria-hidden="true"></i>Intervention</li>
                        
                        
                    </ul>
                    <!-- /SERVICE LIST -->


                </section>
                <!-- /SERVICE -->
                
                
                <!-- WORK -->
                <section id="work">


                    <h3 class="headline scroll-animated-from-right">On-going Mental-health activities</h3>
                    
                    
                    <!-- SHOWCASE -->
                    <div class="showcase">
                       
                       
                        <!-- ITEM -->
                        <div class="item scroll-animated-from-right">
                          
                          
                            <!-- LIGHTBOX LINK -->
                            <a href="#" data-featherlight="#item-1-lightbox">
                            
                            
                                <!-- INFO -->
                                <div class="info">


                                    <!-- CONTAINER MID -->
                                    <div class="container-mid">

                                        <h5>Love your mind</h5>
                                        <p>Mental Health Advocacy by JJAC</p>

                                    </div>
                                    <!-- /CONTAINER MID -->


                                </div>
                                <!-- /INFO -->


                                <div class="background-image" style="background-image: url(assets/img/work/item-1.jpg)"></div>

                           
                            </a>
                            <!-- /LIGHTBOX LINK -->
                            
                            
                            <!-- LIGHTBOX -->
                            <div id="item-1-lightbox" class="work-lightbox">
                               
                               
                                <img id = "medic" src = "https://getwallpapers.com/wallpaper/full/7/e/2/1520338-medical-wallpaper-backgrounds-2048x1365-for-4k.jpg">

                                
                                <h3>Love your mind</h3>
                                <p class="subline"> Mental Health Advocacy by JJAC</p>
                                
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam semper faucibus eros, quis imperdiet sapien. Nam sodales nec risus nec interdum. Proin lobortis, ex condimentum ultricies eleifend, nisl nunc sollicitudin odio, eget egestas est turpis et metus. In non ligula quis mauris rutrum porta.</p>
                                
                                
                            </div>
                            <!-- /LIGHTBOX -->
                            
                            
                        </div>
                        <!-- /ITEM -->
                        
                        
                        <!-- ITEM -->
                        <div class="item scroll-animated-from-right">
                          
                          
                            <!-- LIGHTBOX LINK -->
                            <a href="#" data-featherlight="#item-2-lightbox">
                            
                            
                                <!-- INFO -->
                                <div class="info">


                                    <!-- CONTAINER MID -->
                                    <div class="container-mid">

                                        <h5>Mental-health Prevention Program</h5>
                                        <p>World Health Organization</p>

                                    </div>
                                    <!-- /CONTAINER MID -->


                                </div>
                                <!-- /INFO -->


                                <div class="background-image" style="background-image: url(assets/img/work/item-2.jpg)"></div>

                           
                            </a>
                            <!-- /LIGHTBOX LINK -->
                            
                            
                            <!-- LIGHTBOX -->
                            <div id="item-2-lightbox" class="work-lightbox">
                               
                               
                                <img id = "medic" src = "https://cdn.wallpapersafari.com/35/32/I2khon.jpg">
                                
                                <h3>Mental-health Prevention Program</h3>
                                <p class="subline">World Health Organization</p>
                                <p></p>
                                
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam semper faucibus eros, quis imperdiet sapien. Nam sodales nec risus nec interdum. Proin lobortis, ex condimentum ultricies eleifend, nisl nunc sollicitudin odio, eget egestas est turpis et metus. In non ligula quis mauris rutrum porta.</p>
                                
                                
                            </div>
                            <!-- /LIGHTBOX -->
                            
                            
                        </div>
                        <!-- /ITEM -->
                        
                        
                        <!-- ITEM -->
                        <div class="item scroll-animated-from-right">
                          
                          
                            <!-- LIGHTBOX LINK -->
                            <a href="#" data-featherlight="#item-3-lightbox">
                            
                            
                                <!-- INFO -->
                                <div class="info">


                                    <!-- CONTAINER MID -->
                                    <div class="container-mid">

                                        <h5>Supporting Early Childhood Mental Health</h5>
                                        <p>Webinar by Hunt Institute</p>

                                    </div>
                                    <!-- /CONTAINER MID -->


                                </div>
                                <!-- /INFO -->


                                <div class="background-image" style="background-image: url(assets/img/work/item-3.jpg)"></div>

                           
                            </a>
                            <!-- /LIGHTBOX LINK -->
                            
                            
                            <!-- LIGHTBOX -->
                            <div id="item-3-lightbox" class="work-lightbox">
                               
                               
                                <img id = "medic" src = "https://i.pinimg.com/originals/36/42/29/3642291603d80cbf90ee7421ba227a8b.jpg">
                                
                                <h3>Supporting Early Childhood Mental Health</h3>
                                <p class="subline">Webinar by Hunt Institute</p>
                                
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam semper faucibus eros, quis imperdiet sapien. Nam sodales nec risus nec interdum. Proin lobortis, ex condimentum ultricies eleifend, nisl nunc sollicitudin odio, eget egestas est turpis et metus. In non ligula quis mauris rutrum porta.</p>
                                
                                
                            </div>
                            <!-- /LIGHTBOX -->
                            
                            
                        </div>
                        <!-- /ITEM -->
                        
                        
                        <!-- ITEM -->
                        <div class="item scroll-animated-from-right">
                          
                          
                            <!-- LIGHTBOX LINK -->
                            <a href="#" data-featherlight="#item-4-lightbox">
                            
                            
                                <!-- INFO -->
                                <div class="info">


                                    <!-- CONTAINER MID -->
                                    <div class="container-mid">

                                        <h5>Que Madre! Talks Mental Health with Women in Rural California</h5>
                                        <p>by Lucy Barnum</p>

                                    </div>
                                    <!-- /CONTAINER MID -->


                                </div>
                                <!-- /INFO -->


                                <div class="background-image" style="background-image: url(assets/img/work/item-4.jpg)"></div>

                           
                            </a>
                            <!-- /LIGHTBOX LINK -->
                            
                            
                            <!-- LIGHTBOX -->
                            <div id="item-4-lightbox" class="work-lightbox">
                               
                               
                                <img id = "medic" src = "https://img.rawpixel.com/s3fs-private/rawpixel_images/website_content/rm373batch15-bg-11.jpg?w=1200&h=1200&dpr=1&fit=clip&crop=default&fm=jpg&q=75&vib=3&con=3&usm=15&cs=srgb&bg=F4F4F3&ixlib=js-2.2.1&s=330dde5a4191a3d87204a2f9b040e3fe">
                                
                                <h3>Que Madre! Talks Mental Health with Women in Rural California</h3>
                                <p class="subline">by Lucy Barnum</p>
                                
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam semper faucibus eros, quis imperdiet sapien. Nam sodales nec risus nec interdum. Proin lobortis, ex condimentum ultricies eleifend, nisl nunc sollicitudin odio, eget egestas est turpis et metus. In non ligula quis mauris rutrum porta.</p>
                                
                                
                            </div>
                            <!-- /LIGHTBOX -->
                            
                            
                        </div>
                        <!-- /ITEM -->
                        
                        
                    </div>
                    <!-- /SHOWCASE -->


                </section>
                <!-- /WORK -->
                
                
                <!-- CONTACT -->
                <section id="contact">


                    <h3 class="headline scroll-animated-from-right">Contact Us</h3>
                    
                    
                    <!-- CONTACT LIST -->
                    <ul class="contact-list">
                       
                        <li class="scroll-animated-from-right"><i class="fa fa-mobile" aria-hidden="true"></i>+639973579087</li>
                        <li class="scroll-animated-from-right"><i class="fa fa-envelope-o" aria-hidden="true"></i>risewithus@gmail.com</li>
                        
                    </ul>
                    <!-- /CONTACT LIST -->
                    
                    
                    <!-- CONTACT FORM --> 
                    <form id="contact-form" action="assets/php/contact.php" method="post">

                       
                        <input id="contact-form-name" type="text" name="name" class="form-control scroll-animated-from-right" placeholder="* Your Name">
                        
                        <input id="contact-form-email" type="text" name="email" class="form-control scroll-animated-from-right" placeholder="* Your Email">
                        
                        <!-- PHANTOM ELEMENT ( HONEYPOT CAPTCHA FOR SECURITY ) -->
                        <div class="fhp-input"><input id="contact-form-company" type="text" name="company" class="form-control"></div>
                        <!-- /PHANTOM ELEMENT ( HONEYPOT CAPTCHA FOR SECURITY ) -->
                        
                        <textarea id="contact-form-message" name="message" class="form-control scroll-animated-from-right" placeholder="* Your Message"></textarea>
                        
                        <button type="submit" class="form-control scroll-animated-from-right">Send Mail</button>
                        
                        <div class="success-message">* The Email was Sent Successfully!</div>

                   
                    </form>
                    <!-- /CONTACT FORM --> 


                </section>
                <!-- /CONTACT -->
                
                
                <!-- FOOTER -->
                <section id="footer">
                
                   
                    <!-- SOCIAL ICONS -->
                    <ul class="social-icons scroll-animated-from-right">
                       
                       
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        
                        
                    </ul>
                    <!-- /SOCIAL ICONS -->
                    

                    <p class="scroll-animated-from-right">© 2023 Rise with Us | Design by Group 6 (WD-201) </p>


                </section>
                <!-- /FOOTER -->


            </div>
            <!-- /CONTENT AREA INNER -->


        </div>
            
    </div>

</template>

<style scoped>

html
{
    font-size: 10px;
}

body
{
    font-family: 'Arapey', serif;
    font-weight: 300;
    font-style: normal;

    color: #000;
    background: #fff;

    -webkit-font-smoothing: antialiased;
}

.tagline{
    color: #000;
}

h1,
h2,
h3,
h4,
h5,
h6
{
    font-family: 'Abril Fatface', cursive;
    font-weight: normal;

    letter-spacing: .05em;

    color: #000;;
}

h1
{
    font-size: 4.4rem;
    color: #2596be;
}

h2
{
    font-size: 3.9rem;
}

h3
{
    font-size: 3.4rem;
    color: #2596be;
}

h4
{
    font-size: 2.9rem;
}

h5
{
    font-size: 2.4rem;
}

h6
{
    font-size: 1.9rem;
}

p
{
    font-size: 1.8rem;
}

a,
a:hover,
a:focus
{
    cursor: pointer;
    -webkit-transition: all 300ms ease;
         -o-transition: all 300ms ease;
            transition: all 300ms ease;
    text-decoration: none;
}

a:hover
{
    color: #111;
}

@media (max-width:600px)
{
    html
    {
        font-size: 8px;
    }
}

@media (max-width:500px)
{
    html
    {
        font-size: 7px;
    }
}

.image-container
{
    position: fixed;
    z-index: 10;
    top: 0;
    left: 0;

    width: 50%;
    height: 100%;
}

.image-container .background-img
{
    position: absolute;
    z-index: 1;
    top: 0;
    left: 0;

    width: 100%;
    height: 100%;

    -webkit-transition: opacity 1s ease;
         -o-transition: opacity 1s ease;
            transition: opacity 1s ease;

    background: url(../../assets/rwubg.png);
    background-repeat: no-repeat;
    background-size: cover;
}

@media (max-width:1200px)
{
    .image-container
    {
        position: relative;
        z-index: 10;
        top: 0;
        left: 0;

        width: 100%;
        height: 100vh;
    }
}

.content-area
{
    position: relative;
    left: 0;

    width: 100%;
}

.content-area .content-area-inner
{
    position: relative;
    left: 50%;
    
    width: 50%;
    padding: 0 20px;
    overflow-x: hidden;
}

.content-area .content-area-inner section
{
    max-width: 520px;
    margin: 0 auto 18vh auto;
}

.content-area .content-area-inner section:last-child
{
    margin-bottom: 10vh;
}

.content-area .content-area-inner section h3.headline
{
    margin-bottom: 1.2em;
}

@media (max-width:1200px)
{
    .content-area .content-area-inner
    {
        left: 0;

        width: 100%;
        padding: 0 20px;
    }
}


#about p
{
    line-height: 1.5em;

    margin-bottom: 2em;
}

#about p:last-child
{
    margin-bottom: 0;
}




#service .services-list
{
    margin-bottom: 0;
    padding: 0;

    list-style: none;
}

#service .services-list li
{
    font-size: 2.4rem;
    line-height: 3.4em;
}

#service .services-list li i
{
    font-size: 2rem;
    line-height: 3em;

    width: 3em;
    height: 3em;
    margin-right: 1.5em;

    text-align: center;

    color: #fff;
    border-radius: 100px;
    background: #111;
}



#work .showcase .item
{
    position: relative;

    overflow: hidden;

    width: 100%;
    height: 24rem;
    margin: 0;
    margin-bottom: 6vh;

    cursor: pointer;

    border-radius: 3rem;
    background: #2596be;
}

#work .showcase .item:last-child
{
    margin-bottom: 0;
}

#work .showcase .item .info
{
    position: absolute;
    z-index: 100;
    top: 0;
    left: 0;

    width: 0;
    height: 100%;

    -webkit-transition: .25s ease;
         -o-transition: .25s ease;
            transition: .25s ease;

    color: #fff;
    background: #2596be;
}

#work .showcase .item:hover .info
{
    width: 100%;
}

#work .showcase .item .info .container-mid
{
    position: absolute;
    top: 50%;
    left: 0;

    width: 100%;
    padding: 0 6rem;

    -webkit-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
            transform: translateY(-50%);
}

#work .showcase .item .info .container-mid h5
{
    -webkit-transform: translateX(4vh);
        -ms-transform: translateX(4vh);
            transform: translateX(4vh);

    opacity: 0;
    color: #fff;
}

#work .showcase .item:hover .info .container-mid h5
{
    -webkit-transition: .2s ease .2s;
         -o-transition: .2s ease .2s;
            transition: .2s ease .2s;
    -webkit-transform: translateX(0);
        -ms-transform: translateX(0);
            transform: translateX(0);

    opacity: 1;
}

#work .showcase .item .info .container-mid p
{
    position: relative;

    padding-left: 2.7rem;

    -webkit-transform: translateX(4vh);
        -ms-transform: translateX(4vh);
            transform: translateX(4vh);
    letter-spacing: .025em;

    opacity: 0;
}

#work .showcase .item:hover .info .container-mid p
{
    -webkit-transition: .2s ease .3s;
         -o-transition: .2s ease .3s;
            transition: .2s ease .3s;
    -webkit-transform: translateX(0);
        -ms-transform: translateX(0);
            transform: translateX(0);

    opacity: 1;
}

#work .showcase .item .info .container-mid p:before
{
    position: absolute;
    top: 50%;
    left: 0;

    width: 1.1em;
    height: 1px;

    content: '';
    -webkit-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
            transform: translateY(-50%);

    background: #fff;
}

#work .showcase .item .background-image
{
    position: absolute;
    top: 0;
    left: 0;

    width: 100%;
    height: 100%;

    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.featherlight .featherlight-content
{
    max-height: 95%;
    padding: 0;

    border-bottom: 0;
}

.featherlight .featherlight-content  .featherlight-close-icon
{
    font-size: 2.4rem;
    line-height: 1em;

    top: .5em;
    right: .5em;

    width: 1em;

    outline: none !important;
}

.featherlight .featherlight-content .work-lightbox
{
    max-width: 1000px;
    padding: 6vh;

    text-align: center;
}

.featherlight .featherlight-content .work-lightbox img
{
    margin: 0 auto 4vh auto;
}

.featherlight .featherlight-content .work-lightbox p.subline
{
    margin-bottom: 1em;

    letter-spacing: .025em;
}

.featherlight .featherlight-content .work-lightbox p
{
    max-width: 520px;
    margin: 0 auto;
}




#contact .contact-list
{
    margin-bottom: 3.4em;
    padding: 0;

    list-style: none;
}

#contact .contact-list li
{
    font-size: 2.4rem;
    line-height: 2.4em;
}

#contact .contact-list li i
{
    line-height: 1.2em;

    width: 1.2em;
    height: 1.2em;
    margin-right: 1em;

    text-align: center;

    border-radius: 100px;
}

#contact #contact-form
{
    position: relative;
}

#contact #contact-form .fhp-input
{
    display: none;

    pointer-events: none;

    opacity: 0;
}

#contact #contact-form input,
#contact #contact-form textarea,
#contact #contact-form button
{
    font-size: 2rem;

    margin-bottom: 3.4vh;

    -webkit-transition: .4s ease;
         -o-transition: .4s ease;
            transition: .4s ease;

    color: #fff;
    border: none !important;
    border-radius: 34px;
    outline: none !important;
    background: #111;
    -webkit-box-shadow: none !important;
            box-shadow: none !important;
}

#contact #contact-form.success input,
#contact #contact-form.success textarea,
#contact #contact-form.success button
{
    line-height: 0;

    height: 0;
    margin: 0;
    padding: 0;

    opacity: 0;
}

#contact #contact-form input::-webkit-input-placeholder,
#contact #contact-form textarea::-webkit-input-placeholder
{
    color: #fff;
}

#contact #contact-form input:-ms-input-placeholder,
#contact #contact-form textarea:-ms-input-placeholder
{
    color: #fff;
}

#contact #contact-form input::placeholder,
#contact #contact-form textarea::placeholder
{
    color: #fff;
}

#contact #contact-form input.error,
#contact #contact-form textarea.error
{
    background: red;
}

#contact #contact-form input
{
    line-height: 3.2em;

    height: 3.2em;
    padding-right: 1.6em;
    padding-left: 1.6em;
}

#contact #contact-form textarea
{
    line-height: 1.7em;

    height: 8em;
    padding-top: .7em;
    padding-right: 1.6em;
    padding-left: 1.6em;
}

#contact #contact-form button
{
    line-height: 3.2em;

    position: relative;

    display: inline-block;
    overflow: hidden;

    width: auto;
    height: 3.2em;
    margin-bottom: 0;
    padding: 0 3.6em;

    background: none !important;
}

#contact #contact-form button:before
{
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;

    width: 100%;
    height: 100%;

    content: '';

    border-radius: 100px;
    background: #111;
}

#contact #contact-form button:after
{
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;

    width: 0;
    height: 100%;

    content: '';
    -webkit-transition: .2s ease;
         -o-transition: .2s ease;
            transition: .2s ease;

    background: #008aff;
}

#contact #contact-form button:hover:after
{
    width: 100%;
}

#contact #contact-form .success-message
{
    font-size: 2rem;
    line-height: 0;

    position: relative;
    bottom: 0;
    left: 0;

    height: 0;
    margin-top: -1.6em;
    padding: 0 2em;

    -webkit-transition: .2s ease;
         -o-transition: .2s ease;
            transition: .2s ease;
    pointer-events: none;

    opacity: 0;
    color: #fff;
    border-radius: 3em;
    background: limegreen;
}

#contact #contact-form.success .success-message
{
    line-height: 6em;

    height: 6em;

    pointer-events: all;

    opacity: 1;
}




#footer .social-icons
{
    padding: 0;

    list-style: none;
}

#footer .social-icons li
{
    font-size: 2rem;
    line-height: 3em;

    position: relative;

    display: inline-block;
    overflow: hidden;

    width: 3em;
    height: 3em;
    margin: 0;
    margin-right: 1em;

    text-align: center;

    color: #fff;
    border-radius: 100%;
    background: none;
}

#footer .social-icons li:before
{
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;

    width: 100%;
    height: 100%;

    content: '';

    border-radius: 100px;
    background: #111;
}

#footer .social-icons li:after
{
    position: absolute;
    z-index: -1;
    top: 0;
    left: 0;

    width: 0;
    height: 100%;

    content: '';
    -webkit-transition: .2s ease;
         -o-transition: .2s ease;
            transition: .2s ease;

    background: #008aff;
}

#footer .social-icons li:hover:after
{
    width: 100%;
}

#footer .social-icons li a
{
    font-size: inherit;

    display: block;

    color: #fff;
    border: none;
}

#footer p
{
    margin-top: 1.6em;
}

#footer p a
{
    color: #000;
    border-bottom: 1px solid #111;
}





</style>